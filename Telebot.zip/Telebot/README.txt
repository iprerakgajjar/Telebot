------------------------------------------------------
Project Info
------------------------------------------------------
Project Specification
------------------------------------------------------
Project Name : Telegram Bot
Created By : Prerak Gajjar
github link : https://www.github.co/iprerakgajjar
-------------------------------------------------------
Languages used : Python 3.9
Library : Telebot
Server Used : Replit
-------------------------------------------------------
Description
-------------------------------------------------------
>>This is a Simple Telegram bot where you can perfrom some action like
  download Youtube Videos and get direct link for download wallpapers.

>>I have used Replit server for bot but you can use other servers.

>>For this bot you doesn't need to use '/' for command
--------------------------------------------------------
Commands for Bot
--------------------------------------------------------
Command 1 : ytdownload <youtube video link>

Command 2 : unsplash <wallpaper name like Nature/London/New-york/Mumbai>

Note for Command 2 : if your input has space then use '-' for space like New-York / Los-Angeles otherwise you will get wrong Link.